function function1() {
    alert("Hi how are you?");
}