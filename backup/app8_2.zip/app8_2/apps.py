from django.apps import AppConfig


class App81Config(AppConfig):
    name = 'app8_1'
