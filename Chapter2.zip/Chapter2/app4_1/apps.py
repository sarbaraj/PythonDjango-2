from django.apps import AppConfig


class App41Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app4_1'
