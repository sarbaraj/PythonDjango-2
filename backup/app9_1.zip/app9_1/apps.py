from django.apps import AppConfig


class App91Config(AppConfig):
    name = 'app9_1'
