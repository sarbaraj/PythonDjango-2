from django.apps import AppConfig


class App61Config(AppConfig):
    name = 'app6_1'
