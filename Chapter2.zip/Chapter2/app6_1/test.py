# print("Hello")
import my_module
print(my_module.create_mysql_table())
# insert
# search
# display all
# update
# delete
