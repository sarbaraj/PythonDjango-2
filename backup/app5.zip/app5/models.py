from django.db import models

# Create your models here.
class Person(models.Model):
    pid = models.IntegerField()
    fullname = models.CharField(max_length=50)

